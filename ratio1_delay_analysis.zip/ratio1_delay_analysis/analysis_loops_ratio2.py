#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jul 11 13:49:09 2019

@author: mp525
analysis_loops_script_corr.py
"""


import numpy as np
#import system_ORNPNLN_corr
import matplotlib.pyplot as plt

import pickle        
from os import path
from os import mkdir
from shutil import copyfile

plt.ion()
# *****************************************************************
# STANDARD FIGURE PARAMS
fs = 20
lw = 2
plt.rc('text', usetex=True)  # laTex in the polot
#plt.rc('font', family='serif')
fig_size = [12, 12]
fig_position = 1300,10
title_fs = 20 # font size of ticks
label_fs = 20 # font size of labels
black   = 'xkcd:black'
blue    = 'xkcd:blue'
red     = 'xkcd:red'
green   = 'xkcd:green'
purple  = 'xkcd:purple'
orange  = 'xkcd:orange'
# *****************************************************************

fig_save    = True
data_save   = True
fld_py_h    = '/home/m/mp/mp525/MEGA/WORK/Code/PYTHON/'
fld_py_w    = '/home/mario/MEGA/WORK/Code/PYTHON/'

if path.isdir(fld_py_h):
    fld_py = fld_py_h
elif path.isdir(fld_py_w):
    fld_py = fld_py_w
else:
    print('ERROR: no python folder!')
    
fld_home = fld_py+'NSI_analysis/analysis_ratio/'

fld_analysis = fld_home+'ratio1_delay_analysis/'

n_loops     = 70
    
durs    = [20, 50, 100, 200,]
id_peak2plot =  2
    
delays2an =  [0,10, 20, 50, 100, 200,500,] 
ratio_avg_ln = np.ones((np.size(delays2an),n_loops,np.size(durs)))
ratio_avg_nsi = np.ones((np.size(delays2an),n_loops,np.size(durs)))
ratio_peak_ln = np.ones((np.size(delays2an),n_loops,np.size(durs)))
ratio_peak_nsi = np.ones((np.size(delays2an),n_loops,np.size(durs)))

# save the PRESENT version of this script:
copyfile('analysis_loops_ratio2.py', fld_analysis+'/analysis_loops_ratio2.py') 
        
for id_dur in range(np.size(durs)):
    duration = durs[id_dur]
    dk = -1
    for delay in delays2an:#       = 200
        dk += 1
        fld_analysis_tmp = fld_analysis+'ratio_stim_dur_%d'%duration+'_delay_%d'%delay        
        
        #pickle.dump([params2an, peak_1, ratio_peak, 
        #                                 avg_orn1, avg_orn2, avg_pn1, avg_pn2,
        #                                 peak_orn1, peak_orn2, peak_pn1, peak_pn2]    
        data_name = 'NoIn_ratio_an'
        all_data    = pickle.load( open( fld_analysis_tmp+'/' +data_name+'.pickle',  "rb" ) )
        stim_params = all_data[0]
        conc_1_r    = all_data[1]
        conc_ratio  = all_data[2]
        
        n_peak_ratio, n_peak, n_loops = np.shape(all_data[3])
        
        orn_avg1_noin   = all_data[3]
        orn_avg2_noin   = all_data[4]
        pn_avg1_noin    = all_data[5]
        pn_avg2_noin    = all_data[6]
        
        orn_peak1_noin   = all_data[7]
        orn_peak2_noin   = all_data[8]
        pn_peak1_noin    = all_data[9]
        pn_peak2_noin    = all_data[10]
        
        data_name = 'LN_ratio_an'
        all_data    = pickle.load( open( fld_analysis_tmp+'/' +data_name+'.pickle',  "rb" ) )
        orn_avg1_ln   = all_data[3]
        orn_avg2_ln   = all_data[4]
        pn_avg1_ln    = all_data[5]
        pn_avg2_ln    = all_data[6]
        
        orn_peak1_ln = all_data[7]
        orn_peak2_ln   = all_data[8]
        pn_peak1_ln    = all_data[9]
        pn_peak2_ln    = all_data[10]
        
        data_name = 'NSI_ratio_an'
        all_data    = pickle.load( open( fld_analysis_tmp+'/' +data_name+'.pickle',  "rb" ) )
        orn_avg1_nsi   = all_data[3]
        orn_avg2_nsi   = all_data[4]
        pn_avg1_nsi    = all_data[5]
        pn_avg2_nsi    = all_data[6]
        
        orn_peak1_nsi   = all_data[7]
        orn_peak2_nsi   = all_data[8]
        pn_peak1_nsi    = all_data[9]
        pn_peak2_nsi    = all_data[10]
        
        orn_ratio_avg_nsi   = orn_avg2_nsi/orn_avg1_nsi
        orn_ratio_avg_ln    = orn_avg2_ln/orn_avg1_ln
        orn_ratio_avg_noin  = orn_avg2_noin/orn_avg1_noin
        
        pn_ratio_avg_nsi    = np.ma.masked_invalid(pn_avg2_nsi/pn_avg1_nsi)
        pn_ratio_avg_ln     = np.ma.masked_invalid(pn_avg2_ln/pn_avg1_ln)
        pn_ratio_avg_noin   = np.ma.masked_invalid(pn_avg2_noin/pn_avg1_noin)
        
        orn_ratio_peak_nsi   = orn_peak2_nsi/orn_peak1_nsi
        orn_ratio_peak_ln    = orn_peak2_ln/orn_peak1_ln
        orn_ratio_peak_noin  = orn_peak2_noin/orn_peak1_noin
        
        pn_ratio_peak_nsi    = np.ma.masked_invalid(pn_peak2_nsi/pn_peak1_nsi)
        pn_ratio_peak_ln     = np.ma.masked_invalid(pn_peak2_ln/pn_peak1_ln)
        pn_ratio_peak_noin   = np.ma.masked_invalid(pn_peak2_noin/pn_peak1_noin)
        
        ratio_avg_ln[dk,:, id_dur] = 1/pn_ratio_avg_ln[0,id_peak2plot ,:]
        ratio_avg_nsi[dk,:, id_dur] = 1/pn_ratio_avg_nsi[0,id_peak2plot,:]
        ratio_peak_ln[dk,:, id_dur] = 1/pn_ratio_peak_ln[0,id_peak2plot,:]
        ratio_peak_nsi[dk,:, id_dur] = 1/pn_ratio_peak_nsi[0,id_peak2plot,:]
        
        conc_ratio_t = np.squeeze(conc_ratio[:,0,0])


#%%***********************************************************
## FIGURE avg, several delays
## **********************************************************

fig, axs = plt.subplots(1, np.size(durs), figsize=(15,6), ) 
for id_dur in range(np.size(durs)):
    duration = durs[id_dur]
        
    axs[id_dur].errorbar(delays2an, np.mean(ratio_avg_ln[:,:,id_dur], axis=1), 
       yerr=np.std(ratio_avg_ln[:,:,id_dur], axis=1)/n_loops**.5, label= 'ln avg')
    axs[id_dur].errorbar(delays2an, np.mean(ratio_avg_nsi[:,:,id_dur], axis=1), 
       yerr=np.std(ratio_avg_nsi[:,:,id_dur], axis=1)/n_loops**.5, label= 'nsi avg')    
    
    axs[id_dur].errorbar(delays2an, np.mean(ratio_peak_ln[:,:,id_dur], axis=1), 
       yerr=np.std(ratio_peak_ln[:,:,id_dur], axis=1)/n_loops**.5, label= 'ln peak')
    axs[id_dur].errorbar(delays2an, np.mean(ratio_peak_nsi[:,:,id_dur], axis=1),
       yerr=np.std(ratio_peak_nsi[:,:,id_dur], axis=1)/n_loops**.5, label= 'nsi peak')    
    
    axs[id_dur].set_xlabel('delay (ms)', fontsize=fs)
    axs[id_dur].set_title('Duration: %d ms'%(duration), fontsize=fs)

    axs[id_dur].set_ylim((.9, 2))

conc2plot = np.squeeze(conc_1_r[0,id_peak2plot,0])
axs[0].set_ylabel('freq PN ratio', fontsize=fs)
axs[0].set_title('Duration: %d ms, conc: %.2g'%(durs[0], conc2plot), fontsize=fs)    
axs[0].legend()

if fig_save:
    fig.savefig(fld_analysis+  '/ratio1_delays0-500_dur20-200_conc%.2g'%conc2plot +'.png')
   

#%% **********************************************************
## FIGURE peak
## **********************************************************
peak_fig = 0
if peak_fig: #delay == 00:
    lw = 3
    rs = 2
    cs = 3
    fig, axs = plt.subplots(rs, cs, figsize=(15,6), ) 
    
    colors = plt.cm.winter_r
    clr_fct = 30
    
    conc_1 = conc_1_r[0,:,0]
    for pk in [1,2,3,]: #range(np.size(conc_1)):# [0,1,3,5,7,]:#
        axs[0,0].errorbar(conc_ratio_t, conc_ratio_t/np.squeeze(np.mean(orn_ratio_peak_noin[:,pk,:], axis=1)),
           yerr= np.squeeze(np.std(orn_ratio_peak_noin[:,pk,:], axis=1))/np.sqrt(n_loops), marker='o', 
           label=r'conc1: '+'%.1f'%(conc_1[pk]), color=colors(pk*clr_fct) )
        axs[0,1].errorbar(conc_ratio_t, conc_ratio_t/np.squeeze(np.mean(orn_ratio_peak_ln[:,pk,:], axis=1)),
           yerr= np.squeeze(np.std(orn_ratio_peak_ln[:,pk,:], axis=1))/np.sqrt(n_loops),  marker='o', 
           label=r'conc1: '+'%.1f'%(conc_1[pk]), color=colors(pk*clr_fct) )
        axs[0,2].errorbar(conc_ratio_t, conc_ratio_t/np.squeeze(np.mean(orn_ratio_peak_nsi[:,pk,:], axis=1)),
           yerr= np.squeeze(np.std(orn_ratio_peak_nsi[:,pk,:], axis=1))/np.sqrt(n_loops), marker='o', 
           label=r'conc1: '+'%.1f'%(conc_1[pk]), color=colors(pk*clr_fct) )
        
        axs[1,0].errorbar(conc_ratio_t, conc_ratio_t/np.squeeze(np.mean(pn_ratio_peak_noin[:,pk,:], axis=1)),
           yerr= np.squeeze(np.std(pn_ratio_peak_noin[:,pk,:], axis=1))/np.sqrt(n_loops),  marker='o', 
           label=r'conc1: '+'%.1f'%(conc_1[pk]), 
           color=colors(pk*clr_fct) )
        axs[1,1].errorbar(conc_ratio_t, conc_ratio_t/np.squeeze(np.mean(pn_ratio_peak_ln[:,pk,:], axis=1)),
           yerr= np.squeeze(np.std(pn_ratio_peak_ln[:,pk,:], axis=1))/np.sqrt(n_loops),  marker='o', 
           label=r'conc1: '+'%.1f'%(conc_1[pk]), 
           color=colors(pk*clr_fct) )
        axs[1,2].errorbar(conc_ratio_t, conc_ratio_t/np.squeeze(np.mean(pn_ratio_peak_nsi[:,pk,:], axis=1)),
           yerr= np.squeeze(np.std(pn_ratio_peak_nsi[:,pk,:], axis=1))/np.sqrt(n_loops),
            marker='o', label=r'conc1: '+'%.1f'%(conc_1[pk]), 
           color=colors(pk*clr_fct) )
    
    axs[0,0].errorbar(conc_ratio_t, np.ones_like(conc_ratio_t),lw=lw, color='r', label='theor')
    axs[0,1].errorbar(conc_ratio_t, np.ones_like(conc_ratio_t), lw=lw, color='r', label='theor')
    axs[0,2].errorbar(conc_ratio_t, np.ones_like(conc_ratio_t), lw=lw, color='r', label='theor')
    axs[1,0].errorbar(conc_ratio_t, np.ones_like(conc_ratio_t), lw=lw, color='r', label='theor')
    axs[1,1].errorbar(conc_ratio_t, np.ones_like(conc_ratio_t), lw=lw, color='r', label='theor')
    axs[1,2].errorbar(conc_ratio_t, np.ones_like(conc_ratio_t), lw=lw, color='r', label='theor')
    
    axs[0,0].set_ylabel('Ratio encoding (peak)', fontsize=fs)
    axs[1,0].set_ylabel('Ratio encoding (peak)', fontsize=fs)
    
    axs[0,0].text(2, 3.5, 'ORNs', fontsize=fs)
    axs[1,0].text(2, 5, 'PNs', fontsize=fs)
    
    axs[1,0].set_xlabel('conc ratio', fontsize=fs)
    axs[1,1].set_xlabel('conc ratio', fontsize=fs)
    axs[1,2].set_xlabel('conc ratio', fontsize=fs)
    
    axs[0,0].set_ylim((0, 5))
    axs[0,1].set_ylim((0, 5))
    axs[0,2].set_ylim((0, 5))
    axs[1,0].set_ylim((-2, 6.5))
    axs[1,1].set_ylim((-2, 6.5))
    axs[1,2].set_ylim((-2, 6.5))
    
    axs[0,2].legend()
    axs[0,0].set_title('Independent, dur:%d ms'%stim_params[2]+', delay:%d'%delay, fontsize=fs)
    #axs[0,1].legend()
    axs[0,1].set_title('AL lateral Inhibition', fontsize=fs)
    #axs[0,2].legend()
    axs[0,2].set_title('NSI mechanism', fontsize=fs)
    
    if fig_save:
        fig.savefig(fld_analysis+  '/ratio_stim_peak_dur%d'%stim_params[2]+'_delay%d'%delay+'.png')
#%%
avg_fig = 0
if avg_fig:
    
    rs = 2
    cs = 3
    lw = 3
    fig, axs = plt.subplots(rs, cs, figsize=(15,6), ) 
    
    colors = plt.cm.winter_r
    clr_fct = 30
    
    conc_1 = conc_1_r[0,:,0]
    for pk in [1,2,3,]:#range(np.size(conc_1)):# 
        axs[0,0].errorbar(conc_ratio_t, conc_ratio_t/np.squeeze(np.mean(orn_ratio_avg_noin[:,pk,:], axis=1)),
           yerr= np.squeeze(np.std(orn_ratio_avg_noin[:,pk,:], axis=1))/np.sqrt(n_loops), marker='o', 
           label=r'conc1: '+'%.1f'%(conc_1[pk]),color=colors(pk*clr_fct) )
        axs[0,1].errorbar(conc_ratio_t, conc_ratio_t/np.squeeze(np.mean(orn_ratio_avg_ln[:,pk,:], axis=1)),
           yerr= np.squeeze(np.std(orn_ratio_avg_ln[:,pk,:], axis=1))/np.sqrt(n_loops),  marker='o', 
           label=r'conc1: '+'%.1f'%(conc_1[pk]),color=colors(pk*clr_fct) )
        axs[0,2].errorbar(conc_ratio_t, conc_ratio_t/np.squeeze(np.mean(orn_ratio_avg_nsi[:,pk,:], axis=1)),
           yerr= np.squeeze(np.std(orn_ratio_avg_nsi[:,pk,:], axis=1))/np.sqrt(n_loops), marker='o', 
           label=r'conc1: '+'%.1f'%(conc_1[pk]),color=colors(pk*clr_fct) )
        
        axs[1,0].errorbar(conc_ratio_t, conc_ratio_t/np.squeeze(np.mean(pn_ratio_avg_noin[:,pk,:], axis=1)),
           yerr= np.squeeze(np.std(pn_ratio_avg_noin[:,pk,:], axis=1))/np.sqrt(n_loops),  marker='o', 
           label=r'conc1: '+'%.1f'%(conc_1[pk]), 
           color=colors(pk*clr_fct) )
        axs[1,1].errorbar(conc_ratio_t, conc_ratio_t/np.squeeze(np.mean(pn_ratio_avg_ln[:,pk,:], axis=1)),
           yerr= np.squeeze(np.std(pn_ratio_avg_ln[:,pk,:], axis=1))/np.sqrt(n_loops),  marker='o', 
           label=r'conc1: '+'%.1f'%(conc_1[pk]), 
           color=colors(pk*clr_fct) )
        axs[1,2].errorbar(conc_ratio_t, conc_ratio_t/np.squeeze(np.mean(pn_ratio_avg_nsi[:,pk,:], axis=1)),
           yerr= np.squeeze(np.std(pn_ratio_avg_nsi[:,pk,:], axis=1))/np.sqrt(n_loops),
            marker='o', label=r'conc1: '+'%.1f'%(conc_1[pk]), 
           color=colors(pk*clr_fct) )
    
    axs[0,0].errorbar(conc_ratio_t, np.ones_like(conc_ratio_t),lw=lw, color='r', label='theor')
    axs[0,1].errorbar(conc_ratio_t, np.ones_like(conc_ratio_t), lw=lw, color='r', label='theor')
    axs[0,2].errorbar(conc_ratio_t, np.ones_like(conc_ratio_t), lw=lw, color='r', label='theor')
    axs[1,0].errorbar(conc_ratio_t, np.ones_like(conc_ratio_t), lw=lw, color='r', label='theor')
    axs[1,1].errorbar(conc_ratio_t, np.ones_like(conc_ratio_t), lw=lw, color='r', label='theor')
    axs[1,2].errorbar(conc_ratio_t, np.ones_like(conc_ratio_t), lw=lw, color='r', label='theor')
    
    axs[0,0].set_ylabel('Ratio encoding (avg)', fontsize=fs)
    axs[1,0].set_ylabel('Ratio encoding (avg)', fontsize=fs)
    
    axs[0,0].text(2, 3.5, 'ORNs', fontsize=fs)
    axs[1,0].text(2, 5, 'PNs', fontsize=fs)
    
    axs[1,0].set_xlabel('conc ratio', fontsize=fs)
    axs[1,1].set_xlabel('conc ratio', fontsize=fs)
    axs[1,2].set_xlabel('conc ratio', fontsize=fs)
    
    axs[0,0].set_ylim((0, 5))
    axs[0,1].set_ylim((0, 5))
    axs[0,2].set_ylim((0, 5))
    axs[1,0].set_ylim((-2, 6.5))
    axs[1,1].set_ylim((-2, 6.5))
    axs[1,2].set_ylim((-2, 6.5))
    
    axs[0,2].legend()
    axs[0,0].set_title('Independent, dur:%d ms'%stim_params[2]+', delay:%d ms'%delay, fontsize=fs)
    #axs[0,1].legend()
    axs[0,1].set_title('AL lateral Inhibition', fontsize=fs)
    #axs[0,2].legend()
    axs[0,2].set_title('NSI mechanism', fontsize=fs)
    
    
    if fig_save:
        fig.savefig(fld_analysis+  '/ratio_stim_avg_dur%d'%stim_params[2]+'_delay%d'%delay+'.png')