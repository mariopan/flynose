#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar 21 16:08:11 2019

script name: loops_real_plumes.py
@author: mp525
"""
import system_ORNPNLN_corr_fast

import pickle       
import timeit
from os import path
from os import mkdir
from shutil import copyfile
import matplotlib.pyplot as plt
import sys


stim_seed_start = int(sys.argv[1])
#%%

import numpy as np
import datetime
now = datetime.datetime.now()

inh_conds = ['nsi', 'ln', 'noin']
stim_type = 'pl' # 'ss'   # 'rs'   #  'pl'  # 'ts'
stim_dur  = 201000#0
n_seeds   = 1
    
w_maxs  = [.01,.03,.3, 3, 25, 50, ] # [3,50, 150] # max value in the whiff distribution
b_maxs  = [25] # [25] max value in the blank distribution
rhos    = [0, 1, 3, 5]
peak    = 1.5

sims_to_run = n_seeds*np.size(inh_conds)*np.size(w_maxs)*np.size(b_maxs)*np.size(rhos)
print('Number of Simulations to run: %d '%sims_to_run)

Tot_sim_time = 3.8*sims_to_run*stim_dur/1000/60/60  # hours
run_sim_time = 0
print('Estimated Simulation time: %.3g hours:'%Tot_sim_time)
endsim = now+datetime.timedelta(hours=Tot_sim_time)
print(endsim)
#%%

fld_analysis = 'mario/'#'NSI_analysis/analysis_real_plumes/stim_60s_long_w/'

#if path.isdir(fld_analysis):
#    print('OLD analysis fld: ' + fld_analysis)    
#else:
#    print('NEW analysis fld: ' + fld_analysis)    
#    mkdir(fld_analysis)
copyfile('system_ORNPNLN_corr_fast.py', fld_analysis+'/system_ORNPNLN_corr_fast.py') 
copyfile('loops_real_plumes.py', fld_analysis+'/loops_real_plumes.py') 
    
for stim_seed in np.arange(stim_seed_start, stim_seed_start+n_seeds):
    fld_analysis_tmp = fld_analysis+'real_plumes_%d'%stim_seed
    if path.isdir(fld_analysis_tmp):
        print('OLD analysis fld: ' + fld_analysis_tmp)    
    else:
        print('NEW analysis fld: ' + fld_analysis_tmp)    
        mkdir(fld_analysis_tmp)

    for b_max in b_maxs:
        for w_max in w_maxs:
            for rho in rhos:
                for inh_cond in inh_conds:
                    if inh_cond == 'nsi':
                        params2an = [.3, .0, stim_dur, 0, peak, 1, rho, stim_type,w_max,b_max]
                    elif inh_cond == 'noin':
                        params2an = [0, 0, stim_dur, 0, peak, 1, rho, stim_type,w_max,b_max]
                    elif inh_cond == 'ln':
                        params2an = [.0, .15, stim_dur, 0, peak, 1, rho, stim_type,w_max,b_max]
                    
                    #    params2an = [nsi_value, ln_spike_height, dur2an, delay2an, peak, peak_ratio, rho, stim_type,w_max]
                    plt.ioff()      # ion() # to avoid showing the plot every time     
                    tic = timeit.default_timer()
                    system_ORNPNLN_corr_fast.main(params2an, verbose = False, 
                          fld_analysis = fld_analysis_tmp, stim_seed=stim_seed)
                    plt.close()
                    toc = timeit.default_timer()
                    sims_to_run = sims_to_run - 1
                    print('Remaining Simulations to run: %d '%(sims_to_run))
                    print('Approx Remaining time: %.0f mins'%(sims_to_run*(toc-tic)/60))
    
    print('Tot sim time:%.0f mins'%(run_sim_time))
	    
