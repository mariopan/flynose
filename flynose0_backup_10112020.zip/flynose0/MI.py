#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jul 13 14:38:28 2020

MI.py

@author: mario
"""

# import sklearn
import numpy as np
import timeit


def shan_entropy(c):
    c_normalized = c / float(np.sum(c))
    c_normalized = c_normalized[np.nonzero(c_normalized)]
    H = -sum(c_normalized* np.log2(c_normalized))  
    return H


def main(X,Y,bins):

   c_XY = np.histogram2d(X,Y,bins)[0]
   c_X = np.histogram(X,bins)[0]
   c_Y = np.histogram(Y,bins)[0]

   H_X = shan_entropy(c_X)
   H_Y = shan_entropy(c_Y)
   H_XY = shan_entropy(c_XY)

   MI = H_X + H_Y - H_XY
   return MI


if __name__ == '__main__':
    
    tic = timeit.default_timer()
    # An example with 5 series of 3 elements:
    # A = np.array([[ 2.0,  140.0,  128.23, -150.5, -5.4  ],
    #               [ 2.4,  153.11, -130.34, -100.1, -9.5  ],
    #               [ 1.2,  156.9,  120.11, -110.45,-1.12 ]])
    
    # An example with 5 series of m elements:
    m = 50
    
    A = np.random.normal(0, 1, (m, 5))
    # make series 0 and 1 highly correlated
    A[:, 0] = np.tile(np.linspace(0,9,10),reps= 5)
    A[:, 1] = 2*A[:,0] + 1.1*np.random.normal(0, 1, m)
    
    bins = int((m/5)**.5) +2#5
    
    n = A.shape[1]
    matMI = np.zeros((n, n))
    matCC = np.zeros((n, n))
    
    for ix in np.arange(n):
        for jx in np.arange(ix+1,n):
            matMI[ix,jx] = main(A[:,ix], A[:,jx], bins)
            matCC[ix, jx] = np.corrcoef(A[:,ix], A[:,jx])[1,0] 
    
    print('MI matrix: ')
    print(matMI)
    
    print('corr matrix: ')
    print(matCC)
    
    toc = timeit.default_timer()       
    print('calc time: %.3f s'%(toc-tic))